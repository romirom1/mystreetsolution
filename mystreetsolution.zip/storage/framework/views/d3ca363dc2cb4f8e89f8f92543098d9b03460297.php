<?php $__env->startSection('content'); ?>
    <div class="content">
        <div id="content2">
            <div class="bungkus-beranda">
                <div class="container-fluid">
                <div class="row konten-beranda">
                    <div class="col-md-6 col-sm-6">
                        <div class="col-md-12 col-sm-12">
                        <h3>LAPORAN TERBARU</h3>
                        </div>
                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 col-sm-12">
                        <div class="col-md-4 col-sm-4 col-kiri"><img src="<?php echo e(asset('photo')); ?>/<?php echo e($element->photo); ?>" class="img-fluid img-beranda" style="width: 200px; height: 100px;"></div>
                        <div class="col-md-8 col-sm-8" style="word-wrap: break-word;">
                        <h4><a href="<?php echo e(route('isi.laporan',['id'=> $element->id])); ?>"><?php echo e($element->title); ?></a></h4>
                        <p><em><?php echo e($element->title); ?></em>, <?php echo e($element->content); ?></p>
                        </div>
                        </div>
                        <div class="col-md-12 col-sm-12"><br></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12 col-sm-12"><a class="btn btn-default btn-lihatsemua" role="button" href="<?php echo e(route('semua.laporan')); ?>">LIHAT SEMUA LAPORAN</a> </div>    
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <h3>KATEGORI LAPORAN</h3>
                        <ul class="list-group">
                            <li class="list-group-item nama-list jln-rusak">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 1])); ?>"> <span>Jalan Rusak</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=>1])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list jln-lubang">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 2])); ?>"> <span>Jalan Berlubang</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 2])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list marka-jln">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 3])); ?>"> <span>Marka Jalan</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=>3])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list rambu-lalin">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 4])); ?>"> <span>Rambu Lalu Lintas</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 4])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list lampu-lalin">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 5])); ?>"> <span>Lampu Lalu Lintas</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 5])); ?>">LIHAT </a></li>
                            <li class="list-group-item pmbts-jln">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 6])); ?>"> <span>Pembatas Jalan</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 6])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list trotoar">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 7])); ?>"> <span>Trotoar </span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 7])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list terbengkalai">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 8])); ?>"> <span>Kendaraan Terbengkalai</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 8])); ?>">LIHAT </a></li>
                            <li class="list-group-item nama-list lampu-jln">
                                <a href="<?php echo e(route('kategori.laporan',['id'=> 9])); ?>"> <span>Lampu Penerangan Jalan</span></a><a class="btn btn-default btn-lihatlaporan" role="button" href="<?php echo e(route('kategori.laporan',['id'=> 9])); ?>">LIHAT </a></li>
                        </ul>
                        <h3>STATISTIK LAPORAN</h3>
                        <ul id="list-chart">
                            <div class="container-fluid">
                                <div class="col-md-6 col-sm-6">
                                    <li class="chart-masuk"><?php echo e($count1); ?> </li>
                                    <li class="ket-masuk">LAPORAN MASUK</li>
                                </div>
                                <div class="col-md-6 col-sm-6">
                                    <li class="chart-keluar"><?php echo e($count2); ?></li>
                                    <li class="ket-tuntas">LAPORAN TUNTAS</li>
                                </div>
                            </div>
                            
                            
                        </ul>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>