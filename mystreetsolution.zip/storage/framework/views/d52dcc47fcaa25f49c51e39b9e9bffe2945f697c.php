<?php $__env->startSection('content'); ?>
<div class="row notif-member">
                            <div class="notifikasi-member">
                        <div class="row heading-notifikasi">
                            <div class="col-md-12">
                                <h2>Notifikasi Anda</h2></div>
                        </div>
                        <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row notif-member">
                            <div class="col-md-1"><img src="
                                    <?php if(App\Admin::find($element->admin_id)->photo===""): ?>
                                        <?php echo e(asset('assets/img/avatar_2x.png')); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('photo')); ?>/<?php echo e(App\Admin::find($element->admin_id)->photo); ?>

                                    <?php endif; ?>" class="foto-notif"></div>
                            <div class="col-md-10 notif-isi">
                                <h3><?php echo e(App\Admin::find($element->admin_id)->name); ?></h3>
                                <a href="#"> <span class="judul-laporan-notif">"<?php echo e($element->title); ?>"</span></a>
                                <div class="notif-alasan-penolakan">
                                    <p><?php echo e($element->content); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>