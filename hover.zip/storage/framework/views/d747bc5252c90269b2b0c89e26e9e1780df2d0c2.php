<?php $__env->startSection('content'); ?>
                       <div class="laporan-anda">
                        <div class="row row-header-member">
                            <div class="col-md-12">
                                <h2>Laporan Anda</h2></div>
                        </div>
                        <br>
                        <div class="row row-member-laporan-judul">
                            <div class="col-md-4 col-sm-4 col-laporan-member col-judul">
                                <h3>JUDUL LAPORAN</h3></div>
                            <div class="col-md-4 col-sm-4 col-laporan-member col-komentar">
                                <h3>JUMLAH KOMENTAR</h3></div>
                            <div class="col-md-4 col-sm-4 col-laporan-member col-aksi">
                                <h3>AKSI </h3></div>
                        </div>
                        <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row row-member-laporan-judul">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-isi-laporan isi-judul"><a href="<?php echo e(route('isi.laporan',['id'=> $laporans->id])); ?>" class="member-laporan-isi"><?php echo e($laporans->title); ?></a></div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-isi-laporan isi-komentar">
                                <p class="member-laporan-isi"><?php echo e(App\Comment::all()->where('report_id',$laporans->id)->count()); ?> </p>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-isi-laporan isi-aksi"><a class="btn btn-default member-laporan-isi btn-ubah" role="button" href="<?php echo e(route('edit.laporan',['id'=> $laporans->id])); ?>">UBAH </a><a class="btn btn-default member-laporan-isi btn-hapus" role="button" href="<?php echo e(route('delete.report',['id'=> $laporans->id])); ?>">HAPUS </a></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <div class="row row-member-laporan-judul">
                            <div class="col-lg-12 col-md-12 col-isi-laporan link-bawahlaporan"><?php echo $laporan->links(); ?></div>
                        </div>
                    </div>
                    <div class="statistik-laporan-member">
                        <div class="row heading-statistik-member">
                            <div class="col-md-6 col-sm-6 col-statistik">
                                <h3>Statistik </h3></div>
                            <div class="col-md-6 col-sm-6 col-statistik"><a class="btn btn-default btn-refresh-statistik" role="button" href="#"><i class="glyphicon glyphicon-refresh"></i></a></div>
                        </div>
                        <div class="row isi-statistik-member">
                            <div class="col-md-3 col-sm-3 isi-statistik">
                                <br>
                                <p>Laporan Masuk</p>
                                <h3><?php echo e($count1); ?> </h3>
                                <p>Total Laporan</p>
                            </div>
                            <div class="col-md-9 col-sm-3 isi-statistik">
                                <canvas id="laporandikirim" width="1550" height="400"></canvas></div>
                        </div>
                        <script type="text/javascript">
                            var densityCanvas = document.getElementById("laporandikirim");

                            Chart.defaults.global.defaultFontFamily = "Lato";
                            Chart.defaults.global.defaultFontSize = 12;

                            var densityData = {
                                label: 'Laporan Masuk Tiap Bulan',
                                data: [<?php for($i = 0; $i < 12; $i++): ?>
                                    <?php echo e($data1[$i]); ?>,
                                    <?php endfor; ?>]
                            };

                            var barChart = new Chart(densityCanvas, {
                                type: 'bar',
                                data: {
                                    labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus","September","Oktober","November","Desember"],
                                    datasets: [densityData]
                                }
                            });
                        </script>
                        <div class="row isi-statistik-member row-ke2">
                            <div class="col-md-3 col-sm-3 isi-statistik">
                                <br>
                                <p>Laporan Tuntas</p>
                                <h3><?php echo e($count2); ?> </h3>
                                <p>Total Laporan</p>
                            </div>
                            <div class="col-md-9 col-sm-3 isi-statistik">
                                <canvas id="laporantuntas" width="1550" height="400"></canvas></div>
                        </div>
                        <script type="text/javascript">
                            var densityCanvas = document.getElementById("laporantuntas");

                            Chart.defaults.global.defaultFontFamily = "Lato";
                            Chart.defaults.global.defaultFontSize = 12;

                            var densityData = {
                                label: 'Laporan Tuntas Tiap Bulan',
                                data: [<?php for($i = 0; $i < 12; $i++): ?>
                                    <?php echo e($data2[$i]); ?>,
                                    <?php endfor; ?>]
                            };

                            var barChart = new Chart(densityCanvas, {
                                type: 'bar',
                                data: {
                                    labels: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus","September","Oktober","November","Desember"],
                                    datasets: [densityData]
                                }
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>