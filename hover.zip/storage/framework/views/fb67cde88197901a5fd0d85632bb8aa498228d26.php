<!DOCTYPE html>
<html>
 <head>
  <title>Penggunaan Form di HTML</title>
 </head>
 <body>
  <h4>Isilah formulir dibawah ini dengan baik dan benar ! </h4>
  <hr>
   <form action ="<?php echo e(route('post.report')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    User : <input type="number" name="user_id" size="11px" maxlength="9"> <br><br>
    Kategori :  <select name="categories_id" class="select2">
      <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(old('category_id') == $category->id): ?>
            <option value="<?php echo e($category->id); ?>" selected="selected"><?php echo e($category->name); ?></option>
        <?php else: ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br><br>
    Judul : <input type="text" name="title" size="11px" maxlength="9"> <br><br>
    Isi : <input type="text" name="content" size="40px"> <br><br>
    Lokasi : <input type="text" name="location"> <br><br>
    Photo : <input type="file" name="photo"> <br><br>
    Status : <input type="text" name="status" size="40px"> <br><br>
     <input type="submit" value="SUBMIT">
  </form>
 </body>
</html>