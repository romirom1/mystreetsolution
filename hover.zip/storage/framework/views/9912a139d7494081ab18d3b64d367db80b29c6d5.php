<?php $__env->startSection('content'); ?>
<div class="row notif-member">
                            <div class="notifikasi-member">
                        <div class="row heading-notifikasi">
                            <div class="col-md-12">
                                <h2>Notifikasi Anda</h2></div>
                        </div>
                        <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row notif-member">
                            <div class="col-md-1"><img src="
                                    <?php if(Auth::user()->photo===null): ?>
                                        <?php echo e(asset('assets/img/avatar_2x.png')); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('photo')); ?>/<?php echo e(Auth::user()->photo); ?>

                                    <?php endif; ?>" class="foto-notif"></div>
                            <div class="col-md-10 notif-isi">
                                <h3><?php echo e(Auth::user()->name); ?></h3>
                                <p class="format-notif">Laporan anda yang berjudul</p>
                                <a href="#"> <span class="judul-laporan-notif">"Jalan Berlubang di jalan depan"</span></a>
                                <p class="format-notif">telah ditolak karena,</p>
                                <div class="notif-alasan-penolakan">
                                    <p>"Sobat pria, apakah Anda sudah pernah ditolak oleh wanita? Anda mungkin bertanya-tanya, “Saya sudah melakukan pendekatan yang begitu intensif dan strategik terhadap si wanita, tapi kenapa saya masih juga ditolak? Saya
                                        kurang apa? Mengapa cinta saya ditolak?” sambil mereka-reka setiap langkah yang sudah Anda ambil.Secara mendasar, kegagalan proses pendekatan bertumbuh dari dua bibit kecil, yaitu takut gagal dan tak mau gagal.
                                        Namun secara umum, berikut adalah beberapa penyebab kegagalan PDKT yang paling banyak masuk ke kotak""Sobat pria, apakah Anda sudah pernah ditolak oleh wanita? Anda mungkin bertanya-tanya, “Saya sudah melakukan
                                        pendekatan yang begitu intensif dan strategik terhadap si wanita, tapi kenapa saya masih juga ditolak? Saya kurang apa? Mengapa cinta saya ditolak?” sambil mereka-reka setiap langkah yang sudah Anda ambil.Secara
                                        mendasar, kegagalan proses pendekatan bertumbuh dari dua bibit kecil, yaitu takut gagal dan tak mau gagal. Namun secara umum, berikut adalah beberapa penyebab kegagalan PDKT yang paling banyak masuk ke kotak" </p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>