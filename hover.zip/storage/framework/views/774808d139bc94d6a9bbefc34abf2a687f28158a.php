<?php $__env->startSection('content'); ?>
<div class="laporan-anda">
                        <div class="row row-header-member">
                            <div class="col-md-12">
                                <h2>Laporan Masuk</h2></div>
                        </div>
                        <br>
                        <div class="row admin-laporan-judul">
                            <div class="col-md-3 col-sm-3 col-laporan-admin col-judul">
                                <h4>JUDUL LAPORAN</h4></div>
                            <div class="col-md-2 col-sm-2 col-laporan-admin col-kategori">
                                <h4>KATEGORI </h4></div>
                            <div class="col-md-2 col-sm-2 col-laporan-admin col-tanggal">
                                <h4>TANGGAL MASUK</h4></div>
                            <div class="col-md-2 col-sm-2 col-laporan-admin col-lokasi">
                                <h4>LOKASI LAPORAN</h4></div>
                            <div class="col-md-3 col-sm-3 col-laporan-admin">
                                <h4>Status </h4></div>
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row admin-laporan-isi">
                            <div class="col-lg-3 col-md-3 col-sm-3 admin-isi-laporan col-isi-judul"><a href="<?php echo e(route('isi.laporan',['id'=> $element->id])); ?>" class="member-laporan-isi"><?php echo e($element->title); ?></a></div>
                            <div class="col-lg-2 col-md-2 col-sm-2 admin-isi-laporan col-isi-kategori">
                                <p class="member-laporan-isi"><?php echo e($element->name); ?></p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 admin-isi-laporan col-isi-tanggal">
                                <p class="member-laporan-isi"><?php echo e($element->created_at); ?></p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 admin-isi-laporan col-isi-lokasi">
                                <p class="member-laporan-isi"><?php echo e($element->location); ?> </p>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-3 admin-isi-laporan"><p class="member-laporan-isi"><?php echo e($element->status); ?> </p>
                        </div>  
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="row row-member-laporan-judul">
                            <div class="col-lg-12 col-md-12 col-isi-laporan link-bawahlaporan"><?php echo $data->links(); ?></div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>