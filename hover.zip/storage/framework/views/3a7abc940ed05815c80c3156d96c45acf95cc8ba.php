<?php $__env->startSection('content'); ?>
    <div class="content">
        <div id="content2">
            <div class="bungkus-beranda">
                <?php if($laporan->items()===[]): ?>
                    <div class="row konten-laporan">
                        <div class="col-lg-12 col-md-12">
                            <h3>OOOPS !!! belum ada data yang bisa ditampilkan untuk kategori ini </h3></div>
                    </div>
                <?php else: ?>
                <div class="row konten-laporan">
                    <div class="col-lg-12 col-md-12">
                        <h3>DAFTAR LAPORAN</h3></div>
                </div>
                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row isi-laporan">
                    <div class="col-md-4 col-sm-2 col-kiri"><img src="<?php echo e(asset('photo')); ?>/<?php echo e($value->photo); ?>" class="img-fluid semua-laporan"></div>
                    <div class="col-md-8 col-sm-4 " style="word-wrap: break-word;">
                        <h4><a href="<?php echo e(route('isi.laporan',['id'=> $value->id])); ?>"><?php echo e($value->title); ?></a></h4>
                            <?php echo e($value->content); ?>

                        <ul class="list-daftar-laporan">
                            <li class="laporan-tanggal"><?php echo e($value->created_at); ?> </li>
                            <li class="laporan-komentar">0 Komentar</li>
                            <li class="laporan-nama">Rama </li>
                        </ul>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row row-member-laporan-judul" style="text-align:center">
                            <div class="col-lg-12 col-md-12" ><?php echo $laporan->links(); ?></div>
                        </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>