<?php $__env->startSection('content'); ?>
    <div id="main">
        <div id="bungkus-nav">
        <div class="content main">
            <div id="content2">
                <div class="content-member">
                    <div class="row row-eror"><center><img src="<?php echo e(asset('assets/img/eror.jpg')); ?>" class="img-fluid img-eror"></center>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>